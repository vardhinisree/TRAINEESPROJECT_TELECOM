package com.preparation.assign3;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.*;

public class CrossBrowserTest {
    WebDriver driver;
    @Parameters("browser")
    @BeforeMethod
    public void setup(String browser) {
        driver = BrowserTest.getDriver(browser);
        driver.get("https://example.com/login");
    }
    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
    @Test
    public void testLoginPageTitle() {
        String title = driver.getTitle();
        Assert.assertEquals(title, "Login - Example", "Page title mismatch!");
    }
    @Test
    public void testLoginFunctionality() {
        driver.findElement(By.id("username")).sendKeys("validUser");
        driver.findElement(By.id("password")).sendKeys("validPass");
        driver.findElement(By.id("loginBtn")).click();
        Assert.assertTrue(driver.getCurrentUrl().contains("dashboard"), "Login failed!");
    }
}