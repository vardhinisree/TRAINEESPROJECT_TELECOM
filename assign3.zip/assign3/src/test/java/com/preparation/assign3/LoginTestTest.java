package com.preparation.assign3;

import org.testng.annotations.Test;

public class LoginTestTest {
  @Test
  public void f() {
  }
}
