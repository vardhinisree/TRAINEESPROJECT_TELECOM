package com.preparation.assign3;

import static org.testng.Assert.assertNotNull;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class LoginTest {
    WebDriver driver;
    @BeforeMethod
    public void setup() {
        driver = BrowserTest.getDriver("chrome");
        driver.get("https://www.facebook.com");
    }
    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
    @Test(dataProvider = "loginData", dataProviderClass = CSVDataProvider.class)
    public void testLogin(String username, String password, String expectedResult) {
        driver.findElement(By.id("email")).clear();
        driver.findElement(By.id("email")).sendKeys(username);
        driver.findElement(By.id("pass")).clear();
        driver.findElement(By.id("pass")).sendKeys(password);
      //  driver.findElement(By.id("u_0_0_Vq")).click();
        assertNotNull(username);
       
    }
}
