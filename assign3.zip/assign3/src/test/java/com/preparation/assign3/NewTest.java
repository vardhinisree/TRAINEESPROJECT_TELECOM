package com.preparation.assign3;

import org.testng.annotations.Test;

public class NewTest {
  @Test
  public void f() {
  }
}
