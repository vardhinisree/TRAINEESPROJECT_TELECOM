package com.telecom.Wezen.Enum.copy;

public enum Role {
	customer,
	admin,
	anonymoususer

}
