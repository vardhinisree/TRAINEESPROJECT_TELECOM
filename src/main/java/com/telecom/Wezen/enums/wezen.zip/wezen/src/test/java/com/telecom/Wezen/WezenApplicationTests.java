package com.telecom.Wezen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WezenApplicationTests {

	@Test
	void contextLoads() {
	}

}
