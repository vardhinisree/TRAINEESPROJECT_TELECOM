package com.telecom.Wezen.config;

public class SecurityConfig {

}
